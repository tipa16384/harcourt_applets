public interface GraphElement
{
	public DPoint getOrigin();
	public void setOrigin(DPoint d);
}
